import UpdateProductComponent from "@/app/components/Admin/UpdateProductComponent"

export default function UpdateProduct() {
   
    return (
        <>
            <UpdateProductComponent/>
            
        </>
    )
}