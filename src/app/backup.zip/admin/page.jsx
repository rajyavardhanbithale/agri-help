import CreateProduct from "../components/Admin/CreateProduct"



export default function Main() {
    
    return (
        <>
            <CreateProduct/>
        </>
    )
}