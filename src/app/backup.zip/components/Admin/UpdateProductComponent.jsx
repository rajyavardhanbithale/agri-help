'use client'
import { IonIcon } from '@ionic/react';
import { createOutline } from 'ionicons/icons';

export default function UpdateProductComponent() {

    return (
        <>
            <section className='md:flex mt-10'>
                <section className=" w-full md:h-[600px] md:w-full md:max-w-[1200px] md:grid-cols-1 gap-3 px-5 pb-10 md:grid">
                    <table className="table-fixed">
                        <thead className="h-16 bg-neutral-100">
                            <tr>
                                <th>ITEM</th>
                                <th>PRICE</th>
                                <th>DISCRIPTION </th>
                            </tr>
                        </thead>
                        <tbody>
                            {/* Item 1 */}
                            <tr className="h-[100px] border-b">
                                <div className="flex w-full border px-4 py-4">
                                    <img
                                        className="self-start object-contain"
                                        width="90px"
                                        src="./assets/images/product-chair.png"
                                        alt="Chair image"
                                    />
                                
                                    <div className="ml-3 flex w-full justify-around">
                                        <div className="flex items-center justify-around">
                                            <p className="text-xl font-bold">Seeds</p>
                                            <svg
                                                xmlns="http://www.w3.org/2000/svg"
                                                viewBox="0 0 20 20"
                                                fill="currentColor"
                                                className="h-5 w-5"
                                            >
                                                <path
                                                    d="M10 3a1.5 1.5 0 110 3 1.5 1.5 0 010-3zM10 8.5a1.5 1.5 0 110 3 1.5 1.5 0 010-3zM11.5 15.5a1.5 1.5 0 10-3 0 1.5 1.5 0 003 0z"
                                                />
                                            </svg>
                                        </div>
                                        
                                    </div>
                                    <div class="ml-3 flex w-full justify-around">
                                        <p>
                                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus deleniti assumenda magnam reiciendis hic architecto quam?
                                        </p>
                                    </div>

                                    <div className="ml-3 flex w-full justify-around h-6 w-">
                                        <IonIcon icon={createOutline} className="mr-1 mt-1"></IonIcon> 
                                    </div>
                                </div>
                            </tr>

                            {/* Item 2 */}
                            <tr className="h-[100px] border-b">
                                {/* ... Item 2 contents */}
                            </tr>

                            {/* Item 3 */}
                            <tr className="h-[100px] border-b">
                                {/* ... Item 3 contents */}
                            </tr>

                            {/* Item 4 */}
                            <tr className="h-[100px]">
                                {/* ... Item 4 contents */}
                            </tr>
                        </tbody>
                    </table>
                </section>
            </section>
        </>
    );
}